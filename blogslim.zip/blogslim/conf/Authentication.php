<?php

namespace conf;

class Authentication {

    public static function authenticate($username, $password) {
	res = false;

	// More code needed here
	
        return res;
    }


    public static function logout() {
	// More code needed here
    }

    public static function isAuthenticated() {
	// More code needed here
    }

    public static function getUser() {
	// More code needed here
    }

    // More methods needed here
}
