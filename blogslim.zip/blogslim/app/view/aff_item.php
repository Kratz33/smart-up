<h1>Affichage d'item !</h1>

On me demande d'afficher l'item <?php echo $id; ?>. !

