<h1> Ceci est ma homepage ! </h1>


Un test, on file vers <a href="test">autre chose</a>...
<br />
Un test, on file vers <a href="<?php echo $app->urlFor("testname"); ?>">autre chose</a>...


